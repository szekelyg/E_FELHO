export default () => {
  const planet = 'Earth'
  console.log('Hello, ', planet)

  const hello = function (hi) {
    return hi.toLowerCase()
  }
  hello('Hi Jon')
}
